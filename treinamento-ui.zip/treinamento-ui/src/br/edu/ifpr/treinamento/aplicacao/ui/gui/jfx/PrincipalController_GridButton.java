package br.edu.ifpr.treinamento.aplicacao.ui.gui.jfx;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;

public class PrincipalController_GridButton {
   @FXML
   private GridPane gpPrincipal;

   @FXML
   private Button btnCursos;
   @FXML
   private Button btnMatriculas;
   @FXML
   private Button btnAlunos;
   @FXML
   private Button btnInstrutores;
   @FXML
   private Button btnRelatorios;
   @FXML
   private Button btnServicos;
   @FXML
   private Button btnSair;

   @FXML
   private void initialize() {
      ;
   }
}
