package br.edu.ifpr.treinamento.aplicacao.ui.gui.jfx.utils;

public enum DataEntryState {
   INIT, VIEW, INSERT, EDIT, DELETE, SAVE, CANCEL, SEARCH;
}
