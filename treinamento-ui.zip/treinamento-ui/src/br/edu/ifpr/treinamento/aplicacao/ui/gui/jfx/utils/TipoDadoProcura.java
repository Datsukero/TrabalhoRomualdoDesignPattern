package br.edu.ifpr.treinamento.aplicacao.ui.gui.jfx.utils;

public enum TipoDadoProcura {
   ALFANUMERICO,
   ALFABETICO,
   NUMERICO,
   LOGICO,
   DATA;
}
