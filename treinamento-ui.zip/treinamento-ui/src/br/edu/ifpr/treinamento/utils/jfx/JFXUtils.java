package br.edu.ifpr.treinamento.utils.jfx;

public class JFXUtils {
}
